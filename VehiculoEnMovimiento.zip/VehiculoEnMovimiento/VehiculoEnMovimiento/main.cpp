#include <GL/glut.h>  // Biblioteca para OpenGL Utility Toolkit
#include <math.h>     // Biblioteca para funciones matem�ticas
#include <soil.h>     // Biblioteca para cargar texturas
#include <cstdio>     // Biblioteca para funciones de entrada/salida

int windowWidth = 900;  // Ancho de la ventana
int windowHeight = 600; // Alto de la ventana

GLuint imageFondo;  // Identificador de textura para el fondo
GLuint imagePiso;   // Identificador de textura para el piso
GLfloat cameraZoom = 45.0f;  // Zoom de la c�mara
GLfloat cameraSpeed = 5.0f;  // Velocidad de la c�mara
GLfloat rotateNino = 0.0;    // Rotaci�n del objeto "nino"
float scaleNino = 0.3f;      // Escala del objeto "nino"

float carX = 0.0f;  // Posici�n X del carro
float carY = 0.0f;  // Posici�n Y del carro
float rotateX = 0.0f;  // Rotaci�n en el eje X
float rotateY = 0.0f;  // Rotaci�n en el eje Y
float wheelAngle = 0.0f;  // �ngulo de las ruedas

int prevMouseX = -1;  // Posici�n previa del mouse en X
int prevMouseY = -1;  // Posici�n previa del mouse en Y
bool isRotating = false;  // Indicador de si se est� rotando

// Identificadores de textura para varios objetos
GLuint textureBuilding;
GLuint textureBuilding2;
GLuint textureBuilding3;
GLuint textureBuilding4;
GLuint textureBuilding5;
GLuint textureBuilding6;
GLuint textureBuilding7;
GLuint textureBuilding8;
GLuint texturePiso;
GLuint texturePiso1;
GLuint textureTree;
GLuint textureTree1;

void drawScene() {
    glDisable(GL_LIGHTING);  // Deshabilita la iluminaci�n

    // Primer edificio
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, textureBuilding);  // Vincula la textura del edificio
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(4.0, 6.0, 3.0);  // Escala el edificio
    glTranslatef(3.0, 0.4, -1.0);  // Translada el edificio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();

    // Segundo edificio
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, textureBuilding2);  // Vincula la textura del edificio
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(4.0, 6.0, 3.0);  // Escala el edificio
    glTranslatef(2.0, 0.4, -1.0);  // Translada el edificio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();

    // Tercer edificio
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, textureBuilding3);  // Vincula la textura del edificio
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(2.0, 6.0, 3.0);  // Escala el edificio
    glTranslatef(2.5, 0.4, -1.0);  // Translada el edificio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();

    // Cuarto edificio
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, textureBuilding4);  // Vincula la textura del edificio
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(4, 6.0, 3.0);  // Escala el edificio
    glTranslatef(0.5, 0.4, -1.0);  // Translada el edificio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();

    // �rbol
    glBindTexture(GL_TEXTURE_2D, textureTree);  // Vincula la textura del �rbol
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glPushMatrix();
    glScalef(1, 1.5, 0.5);  // Escala el �rbol
    glTranslatef(-0.8, 3.6, -8.5);  // Translada el �rbol

    glBegin(GL_TRIANGLES);  // Comienza a dibujar tri�ngulos
    glTexCoord2f(0.0, 0.0); glVertex3f(0.0, -0.5, -0.7);   // V�rtice superior
    glTexCoord2f(1.0, 0.0); glVertex3f(-0.3, -1.8, -0.7);  // V�rtice inferior izquierdo
    glTexCoord2f(0.5, 1.0); glVertex3f(0.3, -1.8, -0.7);   // V�rtice inferior derecho

    glTexCoord2f(0.0, 0.0); glVertex3f(0.0, -1.5, -0.7);   // V�rtice superior
    glTexCoord2f(1.0, 0.0); glVertex3f(-0.4, -2.5, -0.7);  // V�rtice inferior izquierdo
    glTexCoord2f(0.5, 1.0); glVertex3f(0.4, -2.5, -0.7);   // V�rtice inferior derecho

    glTexCoord2f(0.0, 0.0); glVertex3f(0.0, -2.0, -0.7);   // V�rtice superior
    glTexCoord2f(1.0, 0.0); glVertex3f(-0.5, -3.0, -0.7);  // V�rtice inferior izquierdo
    glTexCoord2f(0.5, 1.0); glVertex3f(0.5, -3.0, -0.7);   // V�rtice inferior derecho
    glEnd();
    glPopMatrix();

    glPushMatrix();  // Guarda el estado actual de la matriz
    glBindTexture(GL_TEXTURE_2D, textureTree1);  // Vincula la textura del �rbol
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(0.5, 1.5, 0.5);  // Escala el �rbol
    glTranslatef(-1.5, 0.1, -8.5);  // Translada el �rbol
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Dibuja el quinto edificio
    glPushMatrix();  // Guarda el estado actual de la matriz
    glBindTexture(GL_TEXTURE_2D, textureBuilding5);  // Vincula la textura del edificio
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(2.5, 6.0, 3.0);  // Escala el edificio
    glTranslatef(-1.1, 0.4, -1.0);  // Translada el edificio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Dibuja el sexto edificio
    glPushMatrix();  // Guarda el estado actual de la matriz
    glBindTexture(GL_TEXTURE_2D, textureBuilding6);  // Vincula la textura del edificio
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(-2.0, 6.0, 3.0);  // Escala el edificio (nota: escala negativa en X)
    glTranslatef(2.5, 0.4, -1.0);  // Translada el edificio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Dibuja el setimo edificio
    glPushMatrix();  // Guarda el estado actual de la matriz
    glBindTexture(GL_TEXTURE_2D, textureBuilding7);  // Vincula la textura del edificio
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(4.0, 6.0, 3.0);  // Escala el edificio
    glTranslatef(-2.0, 0.4, -1.0);  // Translada el edificio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Dibuja el octavo edificio
    glPushMatrix();  // Guarda el estado actual de la matriz
    glBindTexture(GL_TEXTURE_2D, textureBuilding8);  // Vincula la textura del edificio
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glScalef(4.0, 6.0, 3.0);  // Escala el edificio
    glTranslatef(-3.0, 0.4, -1.0);  // Translada el edificio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0, 0.0); glVertex3f(-0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 0.0); glVertex3f(0.5, -0.5, -0.5);
    glTexCoord2f(1.0, 1.0); glVertex3f(0.5, 0.5, -0.5);
    glTexCoord2f(0.0, 1.0); glVertex3f(-0.5, 0.5, -0.5);
    glEnd();
    glPopMatrix();  // Restaura el estado anterior de la matriz



    // Dibujar la pista de un carro
    // Pista - Rect�ngulo principal
    glPushMatrix();  // Guarda el estado actual de la matriz
    glBindTexture(GL_TEXTURE_2D, texturePiso);  // Vincula la textura de la pista
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    //glTranslatef(0.0f, -0.5f, 0.0f);  // Traslada la pista (comentado)
    //glScalef(2.0f, 0.1f, 14.0f);  // Escala la pista (comentado)
    //glutSolidCube(1.0f);  // Dibuja un cubo s�lido (comentado)
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-14.50f, -0.4f, 3.0f);
    glTexCoord2f(5.0f, 0.0f); glVertex3f(14.5f, -0.4f, 3.0f);
    glTexCoord2f(5.0f, 5.0f); glVertex3f(14.5f, -0.4f, -3.0f);
    glTexCoord2f(0.0f, 5.0f); glVertex3f(-14.5f, -0.4f, -3.0f);
    glEnd();
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Pista de ladrillos de fondo
    glPushMatrix();  // Guarda el estado actual de la matriz
    glBindTexture(GL_TEXTURE_2D, texturePiso1);  // Vincula la textura de los ladrillos
    glColor3f(1.0, 1.0, 1.0);  // Establece el color a blanco
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glTexCoord2f(0.0f, 0.0f); glVertex3f(-14.5f, -0.5f, 8.0f);
    glTexCoord2f(5.0f, 0.0f); glVertex3f(14.5f, -0.5f, 8.0f);
    glTexCoord2f(5.0f, 5.0f); glVertex3f(14.5f, -0.5f, -8.0f);
    glTexCoord2f(0.0f, 5.0f); glVertex3f(-14.5f, -0.5f, -8.0f);
    glEnd();
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glFlush();  // Fuerza la ejecuci�n de las operaciones de OpenGL
    glEnable(GL_LIGHTING);  // Habilita la iluminaci�n
}

void drawMirrors() {
    // Trapecio
    glBegin(GL_QUADS);  // Comienza a dibujar un cuadrado
    glVertex3f(-1.9f, -0.25f, 0.0f);  // V�rtice inferior izquierdo
    glVertex3f(0.8f, -0.25f, 0.0f);   // V�rtice inferior derecho
    glVertex3f(0.5f, 0.3f, 0.0f);    // V�rtice superior derecho
    glVertex3f(-1.5f, 0.3f, 0.0f);   // V�rtice superior izquierdo
    glEnd();
}

void DrawCarBody() {

    glDisable(GL_TEXTURE_2D);  // Deshabilita las texturas
    glDisable(GL_LIGHTING);    // Deshabilita la iluminaci�n temporalmente
    

    glColor3f(0.0f, 0.0f, 1.0f);  // Color Azul 
    // Cuerpo principal
    glPushMatrix();  // Guarda el estado actual de la matriz
    glScalef(2.5f, 0.4f, 0.65f);  // Escala la carrocer�a
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Parte frontal (Izquierda)
    glColor4f(0.2f, 0.2f, 0.3f, 0.8f);  // Establece el color con transparencia
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(0.7f, 0.35f, 0.0f);  // Traslada la parte frontal
    glRotatef(30.0f, 0.0f, 0.0f, 1.0f);  // Rota la parte frontal
    glScalef(0.01f, 0.4f, 0.65f);  // Escala la parte frontal
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(0.5f, 0.0f, 0.2f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Parte trasera (Derecha)
    glColor4f(0.2f, 0.2f, 0.3f, 0.8f);  // Establece el color con transparencia
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(-0.7f, 0.35f, 0.0f);  // Traslada la parte trasera
    glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);  // Rota la parte trasera
    glScalef(0.01f, 0.4f, 0.65f);  // Escala la parte trasera
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(0.5f, 0.0f, 0.2f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Techo
    glColor3f(0.0f, 0.0f, 1.0f);  // Azul 
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(0.0f, 0.55f, 0.0f);  // Mueve el techo hacia arriba
    glScalef(1.2f, 0.01f, 0.65f);  // Escala el techo
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(1.0f, 1.0f, 1.0f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Ventana frontal
    glColor3f(0.5f, 0.0f, 0.2f);  // Establece el color de la ventana frontal
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(0.0f, 0.35f, 0.325f);  // Traslada la ventana frontal
    glScalef(0.03f, 0.34f, 0.01f);  // Escala la ventana frontal
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(1.0f, 1.0f, 1.0f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Ventana trasera
    glColor3f(0.5f, 0.0f, 0.2f);  // Establece el color de la ventana trasera
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(0.0f, 0.35f, -0.325f);  // Traslada la ventana trasera
    glScalef(0.03f, 0.34f, 0.01f);  // Escala la ventana trasera
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(1.0f, 1.0f, 1.0f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glColor4f(0.2f, 0.2f, 0.3f, 0.8f);  // Establece el color con transparencia
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(0.31f, 0.35f, -0.325f);  // Ajusta las coordenadas de traslaci�n para que coincida con el cubo
    glScalef(0.6f, 0.6f, 0.01f);  // Ajusta las coordenadas de escala
    drawMirrors();  // Dibuja los espejos
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Placa delantera
     glColor3f(0.0f, 0.0f, 1.0f);  // Azul 
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(-1.28f, -0.1f, 0.0f);  // Traslada la placa delantera
    glScalef(0.01f, 0.08f, 0.3f);  // Escala la placa delantera
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(0.5f, 0.0f, 0.2f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Placa trasera
    glColor3f(1.0f, 1.0f, 1.0f);  // Establece el color de la placa trasera
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(1.28f, -0.1f, 0.0f);  // Traslada la placa trasera
    glScalef(0.01f, 0.08f, 0.3f);  // Escala la placa trasera
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(0.5f, 0.0f, 0.2f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Parachoques delantero
    glColor3f(0.2f, 0.2f, 0.3f);//Color gris
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(-1.28f, -0.19f, 0.0f);  // Traslada el parachoques delantero
    glScalef(0.01f, 0.03f, 0.6f);  // Escala el parachoques delantero
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(0.0f, 0.0f, 0.0f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Parachoques trasero
    glColor3f(0.2f, 0.2f, 0.3f);//Color gris
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(1.28f, -0.19f, 0.0f);  // Traslada el parachoques trasero
    glScalef(0.01f, 0.03f, 0.6f);  // Escala el parachoques trasero
    glutSolidCube(1.0f);  // Dibuja un cubo s�lido
    glColor3f(0.0f, 0.0f, 0.0f);  // Establece el color del alambre
    glutWireCube(1.0f);  // Dibuja un cubo de alambre
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // M�scara
    glColor3f(0.2f, 0.2f, 0.3f);  // Establece el color de la m�scara
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(-1.28f, 0.01f, -0.05f);  // Traslada la m�scara
    glRotatef(90.0f, 0.0f, 1.0f, 0.0f);  // Rota la m�scara
    glScalef(0.1f, 0.1f, 0.4f);  // Escala la m�scara
    drawMirrors();  // Dibuja los espejos
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Luces delanteras
    glColor3f(1.0f, 1.0f, 0.0f);  // Establece el color de las luces delanteras
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(-1.24f, 0.01f, -0.25);  // Traslada la luz delantera izquierda
    glutSolidSphere(0.05, 50, 50);  // Dibuja una esfera s�lida
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glColor3f(1.0f, 1.0f, 0.0f);  // Establece el color de las luces delanteras
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(-1.24f, 0.01f, 0.25);  // Traslada la luz delantera derecha
    glutSolidSphere(0.05, 50, 50);  // Dibuja una esfera s�lida
    glPopMatrix();  // Restaura el estado anterior de la matriz
    // Luces traseras
    glColor3f(1.0, 0.6, 0.0);  // Establece el color de la luz trasera
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(1.24f, 0.01f, 0.25);  // Traslada la luz trasera
    glutSolidSphere(0.05, 50, 50);  // Dibuja una esfera s�lida
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glColor3f(1.0, 0.0, 0.0);  // Establece el color de la luz trasera
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(1.24f, 0.13f, 0.25);  // Traslada la luz trasera
    glutSolidSphere(0.05, 50, 50);  // Dibuja una esfera s�lida
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glColor3f(1.0, 1.0, 1.0);  // Establece el color de la luz trasera
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(1.24f, -0.10f, 0.25);  // Traslada la luz trasera
    glutSolidSphere(0.05, 50, 50);  // Dibuja una esfera s�lida
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glColor3f(1.0, 0.6, 0.0);  // Establece el color de la luz trasera
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(1.24f, 0.01f, -0.25);  // Traslada la luz trasera
    glutSolidSphere(0.05, 50, 50);  // Dibuja una esfera s�lida
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glColor3f(1.0, 0.0, 0.0);  // Establece el color de la luz trasera
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(1.24f, 0.13f, -0.25);  // Traslada la luz trasera
    glutSolidSphere(0.05, 50, 50);  // Dibuja una esfera s�lida
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glColor3f(1.0, 1.0, 1.0);  // Establece el color de la luz trasera
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(1.24f, -0.10f, -0.25);  // Traslada la luz trasera
    glutSolidSphere(0.05, 50, 50);  // Dibuja una esfera s�lida
    glPopMatrix();  // Restaura el estado anterior de la matriz

    // Espejo derecho (rect�ngulo negro)
    glColor3f(0.0, 0.0, 0.0);  // Establece el color del espejo derecho
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(-0.75f, 0.2f, -0.35f);  // Traslada el espejo derecho
    glScalef(0.3f, 0.8f, 0.8f);  // Escala el espejo derecho
    glutSolidCube(0.1);  // Dibuja un cubo s�lido
    glPopMatrix();  // Restaura el estado anterior de la matriz

    

    // Espejo izquierdo (rect�ngulo negro)
    glColor3f(0.0, 0.0, 0.0);  // Establece el color del espejo izquierdo
    glPushMatrix();  // Guarda el estado actual de la matriz
    glTranslatef(-0.75f, 0.2f, 0.35f);  // Traslada el espejo izquierdo
    glScalef(0.3f, 0.8f, 0.8f);  // Escala el espejo izquierdo
    glutSolidCube(0.1);  // Dibuja un cubo s�lido
    glPopMatrix();  // Restaura el estado anterior de la matriz

   
}



void DrawRimDetails() {
    float angle = 0.0f;
    float theta = 0.0f;
    glColor3f(0.5f, 0.5f, 0.5f); // Color gris para los rines

    // Detalles de los rines
    glBegin(GL_LINE_STRIP);
    for (theta = 0; theta < 360; theta = theta + 40) {
        glVertex3f(-0.6, -0.2, 0.3);
        glVertex3f(-0.6 + (0.08 * (cos(((theta + angle) * 3.14) / 180))), -0.2 + (0.08 * (sin(((theta + angle) * 3.14) / 180))), 0.3);
    }
    glEnd();

    glBegin(GL_LINE_STRIP);
    for (theta = 0; theta < 360; theta = theta + 40) {
        glVertex3f(0.6, -0.2, 0.3);
        glVertex3f(0.6 + (0.08 * (cos(((theta + angle) * 3.14) / 180))), -0.2 + (0.08 * (sin(((theta + angle) * 3.14) / 180))), 0.3);
    }
    glEnd();

    glBegin(GL_LINE_STRIP);
    for (theta = 0; theta < 360; theta = theta + 40) {
        glVertex3f(-0.6, -0.2, -0.3);
        glVertex3f(-0.6 + (0.08 * (cos(((theta + angle) * 3.14) / 180))), -0.2 + (0.08 * (sin(((theta + angle) * 3.14) / 180))), -0.3);
    }
    glEnd();

    glBegin(GL_LINE_STRIP);
    for (theta = 0; theta < 360; theta = theta + 40) {
        glVertex3f(0.6, -0.2, -0.3);
        glVertex3f(0.6 + (0.08 * (cos(((theta + angle) * 3.14) / 180))), -0.2 + (0.08 * (sin(((theta + angle) * 3.14) / 180))), -0.3);
    }
    glEnd();
}

void DrawWheels() {
    glColor3f(0.0f, 0.0f, 0.0f); // Color de las ruedas

    // Rueda delantera izquierda
    glPushMatrix();
    glTranslatef(-0.6f, -0.2f, 0.3f); // Posici�n de la rueda
    glRotatef(wheelAngle, 0.0f, 0.0f, 1.0f); // Rotaci�n de la rueda
    glutSolidTorus(0.1, 0.2, 10, 10); // Dibuja un toro s�lido
    glPopMatrix();

    // Rueda delantera derecha
    glPushMatrix();
    glTranslatef(0.6f, -0.2f, 0.3f); // Posici�n de la rueda
    glRotatef(wheelAngle, 0.0f, 0.0f, 1.0f); // Rotaci�n de la rueda
    glutSolidTorus(0.1, 0.2, 10, 10); // Dibuja un toro s�lido
    glPopMatrix();

    // Rueda trasera izquierda
    glPushMatrix();
    glTranslatef(-0.6f, -0.2f, -0.3f); // Posici�n de la rueda
    glRotatef(wheelAngle, 0.0f, 0.0f, 1.0f); // Rotaci�n de la rueda
    glutSolidTorus(0.1, 0.2, 10, 10); // Dibuja un toro s�lido
    glPopMatrix();

    // Rueda trasera derecha
    glPushMatrix();
    glTranslatef(0.6f, -0.2f, -0.3f); // Posici�n de la rueda
    glRotatef(wheelAngle, 0.0f, 0.0f, 1.0f); // Rotaci�n de la rueda
    glutSolidTorus(0.1, 0.2, 10, 10); // Dibuja un toro s�lido
    glPopMatrix();

    DrawRimDetails(); // Dibuja los detalles de los rines
}

void drawCylinder(double radius, double height) {
    GLUquadric* quadric = gluNewQuadric(); // Crea un nuevo objeto cuadr�tico
    gluQuadricDrawStyle(quadric, GLU_FILL); // Establece el estilo de dibujo
    gluCylinder(quadric, radius, radius, height, 50, 50); // Dibuja un cilindro
    gluDeleteQuadric(quadric); // Elimina el objeto cuadr�tico
}

void drawCube(double size) {
    glBegin(GL_QUADS);
    // Definir caras del cubo
    glEnd();
}


void DrawPerson(float posX, float posY, float posZ, float scale) {
    glPushMatrix();
    glTranslatef(posX, posY, posZ);  // Posiciona la persona
    glRotatef(rotateNino, 0.0, 1.0, 0.0);
    glScalef(scale, scale, scale);  // Escala la persona

    glDisable(GL_TEXTURE_2D);  // Deshabilita las texturas
    glDisable(GL_LIGHTING);    // Deshabilita la iluminaci�n temporalmente

    // Cabeza
    glPushMatrix();
    glTranslatef(0.0, 2.0, 0.0);
    glColor3f(1.0, 0.8, 0.6);  // Color piel (tono claro)
    glutSolidSphere(1.0, 50, 50);
    glPopMatrix();

    // Torso (cubo)
    glPushMatrix();
    glTranslatef(0.0, 0.0, 0.0);
    glColor3f(1.0, 0.0, 0.0);  // Rojo
    glutSolidCube(2.0);
    glPopMatrix();

    // Piernas (cilindros orientados verticalmente)
    glPushMatrix();
    glTranslatef(-0.5, -1.0, 0.0);
    glColor3f(0.0, 0.6, 1.0);  // Azul claro
    glRotatef(90.0, 1.0, 0.0, 0.0);
    drawCylinder(0.5, 2.0);
    glTranslatef(1.0, 0.0, 0.0);
    drawCylinder(0.5, 2.0);
    glPopMatrix();

    // Brazos (cilindros orientados verticalmente)
    glPushMatrix();
    glTranslatef(-1.4, 1.0, 0.0);
    glColor3f(0.0, 0.6, 1.0);  // Azul claro
    glRotatef(90.0, 1.0, 0.0, 0.0);
    drawCylinder(0.3, 1.5);
    glTranslatef(2.8, 0.0, 0.0);
    drawCylinder(0.3, 1.5);
    glPopMatrix();

    glEnable(GL_LIGHTING);  // Habilita la iluminaci�n de nuevo
    glEnable(GL_TEXTURE_2D);  // Habilita las texturas de nuevo

    glPopMatrix();
}




void Reshape(int w, int h) {
    windowWidth = w;  // Actualiza el ancho de la ventana
    windowHeight = h;  // Actualiza el alto de la ventana

    glClearColor(0.0, 0.0, 0.0, 0.0);  // Establece el color de fondo a negro

    glViewport(0, 0, w, h);  // Configura el �rea de visualizaci�n
    glMatrixMode(GL_PROJECTION);  // Cambia a la matriz de proyecci�n
    glLoadIdentity();  // Resetea la matriz de proyecci�n
    gluPerspective(45.0, (float)w / h, 0.1, 100.0);  // Configura la perspectiva
    glMatrixMode(GL_MODELVIEW);  // Cambia a la matriz de modelo/vista

    glLoadIdentity();  // Resetea la matriz de modelo/vista
    gluLookAt(0.0, 12.0, 5.0,  // Posici�n de la c�mara
        0.0, 0.0, 0.0,  // Punto de referencia
        0.0, 1.0, 0.0);  // Vector de arriba
}

void Display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  // Limpia el buffer de color y profundidad

    // Dibujar escena con textura
    glPushMatrix();  // Guarda el estado actual de la matriz
    drawScene();  // Llama a la funci�n para dibujar la escena
    glPopMatrix();  // Restaura el estado anterior de la matriz

    glDisable(GL_TEXTURE_2D);  // Deshabilita las texturas

    // Configuraci�n de la c�mara
    glMatrixMode(GL_PROJECTION);  // Cambia a la matriz de proyecci�n
    glLoadIdentity();  // Resetea la matriz de proyecci�n
    gluPerspective(cameraZoom, 900.0f / 600.0f, 0.1f, 100.0f);  // Configura la perspectiva
    glMatrixMode(GL_MODELVIEW);  // Cambia a la matriz de modelo/vista

    glClearColor(0.5f, 0.7f, 1.0f, 1.0f);  // Establece el color de fondo a un azul claro
    glLoadIdentity();  // Resetea la matriz de modelo/vista

    glTranslatef(0.0f, 0.0f, -7.0f);  // Traslada la escena hacia atr�s
    glTranslatef(carX, carY, 0.0f);  // Aplica la traslaci�n del carro

    glRotatef(rotateX, 1.0f, 0.0f, 0.0f);  // Rota la escena en el eje X
    glRotatef(rotateY, 0.0f, 1.0f, 0.0f);  // Rota la escena en el eje Y

    DrawCarBody();  // Dibuja el cuerpo del carro
    DrawWheels();  // Dibuja las ruedas del carro
    DrawPerson(5.0f, 0.1f, -3.0f, 0.2f);  // Persona 1
    DrawPerson(-5.0f, 0.1f, -3.0f, 0.2f);  // Persona 2
    DrawPerson(2.0f, 0.1f, 3.0f, 0.2f);  // Persona 2

    glEnable(GL_TEXTURE_2D);  // Habilita las texturas para el siguiente frame

    glutSwapBuffers();  // Intercambia los buffers de la ventana
}

void Mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {
            prevMouseX = x;
            prevMouseY = y;
            isRotating = true;
        }
        else {
            isRotating = false;
        }
    }
}

void Motion(int x, int y) {
    if (isRotating) {
        rotateY += (x - prevMouseX) * 0.5f;
        rotateX += (y - prevMouseY) * 0.5f;

        if (rotateX > 90.0f) rotateX = 90.0f;
        if (rotateX < -90.0f) rotateX = -90.0f;

        prevMouseX = x;
        prevMouseY = y;
        glutPostRedisplay();
    }
}

void Keyboard(unsigned char key, int x, int y) {
    // Movimiento del carro con teclas 'a', 'd', 'w', 'x'
    if (key == 'a' || key == 'A') {
        if (carX - 0.1f >= -5.0f)
            carX -= 0.1f;  // Mueve el carro a la izquierda
        else
            carX = 3.0f;  // Resetea la posici�n del carro
    }
    if (key == 'd' || key == 'D') {
        if (carX + 0.1f <= 5.0f)
            carX += 0.1f;  // Mueve el carro a la derecha
        else
            carX = -3.0f;  // Resetea la posici�n del carro
    }
    if (key == 'w' || key == 'W') {
        if (carY + 0.1f <= 5.0f)
            carY += 0.1f;  // Mueve el carro hacia adelante
        else
            carY = -3.0f;  // Resetea la posici�n del carro
    }
    if (key == 's' || key == 'S') {
        if (carY - 0.1f >= -5.0f)
            carY -= 0.1f;  // Mueve el carro hacia atr�s
        else
            carY = 3.0f;  // Resetea la posici�n del carro
    }
    // Control del zoom de la c�mara
    if (key == '-') cameraZoom += cameraSpeed;
    if (key == '+') cameraZoom -= cameraSpeed;
    if (cameraZoom <= 1.0f) cameraZoom = 1.0f;  // Limita el zoom m�nimo
    if (cameraZoom >= 45.0f) cameraZoom = 45.0f;  // Limita el zoom m�ximo

    glutPostRedisplay();  // Redibuja la pantalla
}

void SpecialKeys(int key, int x, int y) {
    switch (key) {
    case GLUT_KEY_LEFT:
        if (carX - 0.1f >= -2.2f) {
            carX -= 0.1f;  // Mueve el carro a la izquierda
        }
        break;
    case GLUT_KEY_RIGHT:
        if (carX + 0.1f <= 2.2f) {
            carX += 0.1f;  // Mueve el carro a la derecha
        }
        break;
    case GLUT_KEY_UP:
        if (carY + 0.1f <= 2.2f) {
            carY += 0.1f;  // Mueve el carro hacia adelante
        }
        break;
    case GLUT_KEY_DOWN:
        if (carY - 0.1f >= -2.2f) {
            carY -= 0.1f;  // Mueve el carro hacia atr�s
        }
        break;
    }

    glutPostRedisplay();  // Redibuja la pantalla
}

void UpdateWheels(int value) {
    wheelAngle += 5.0f;  // Incrementa el �ngulo de las ruedas
    if (wheelAngle >= 360.0f) wheelAngle -= 360.0f;  // Resetea el �ngulo si es necesario
    glutPostRedisplay();  // Redibuja la pantalla
    glutTimerFunc(100, UpdateWheels, 0);  // Configura el temporizador para actualizar las ruedas
}


void init() {
    // Habilitar pruebas de profundidad y texturas
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_2D);

    // Cargar texturas
    textureBuilding = SOIL_load_OGL_texture("thirdbuilding.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    textureBuilding2 = SOIL_load_OGL_texture("thirdbuilding1.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    textureBuilding3 = SOIL_load_OGL_texture("buildings3.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    textureBuilding4 = SOIL_load_OGL_texture("buildings4.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    textureBuilding5 = SOIL_load_OGL_texture("thirdbuilding.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    textureBuilding6 = SOIL_load_OGL_texture("thirdbuilding1.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    textureBuilding7 = SOIL_load_OGL_texture("buildings3.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    textureBuilding8 = SOIL_load_OGL_texture("buildings4.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    texturePiso1 = SOIL_load_OGL_texture("pisoLadrillo.jpg", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_TEXTURE_REPEATS);
    texturePiso = SOIL_load_OGL_texture("carreteraHorizontal.jpg", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_TEXTURE_REPEATS);
    textureTree = SOIL_load_OGL_texture("grass.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);
    textureTree1 = SOIL_load_OGL_texture("treeside.bmp", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_INVERT_Y);

    // Configurar el modo de textura
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

    // Configurar las fuentes de luz
    GLfloat light_position[] = { 0.0f, 5.0f, 5.0f, 1.0f };
    GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };

    glEnable(GL_LIGHTING);  // Habilitar iluminaci�n
    glEnable(GL_LIGHT0);  // Habilitar la luz 0

    glLightfv(GL_LIGHT0, GL_POSITION, light_position);  // Establecer la posici�n de la luz
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);  // Establecer la luz difusa

    glEnable(GL_DEPTH_TEST);  // Habilitar pruebas de profundidad
    glEnable(GL_NORMALIZE);  // Normalizar las normales
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);  // Inicializar GLUT
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);  // Configurar el modo de visualizaci�n
    glutInitWindowSize(windowWidth, windowHeight);  // Establecer el tama�o de la ventana
    glutInitWindowPosition(550, 200);  // Establecer la posici�n de la ventana

    glutCreateWindow("Vehiculo en movimiento");  // Crear la ventana
    init();  // Llamar a la funci�n de inicializaci�n

    // Registrar las funciones de devoluci�n de llamada
    glutDisplayFunc(Display);
    glutReshapeFunc(Reshape);
    glutMouseFunc(Mouse);
    glutMotionFunc(Motion);
    glutKeyboardFunc(Keyboard);
    glutSpecialFunc(SpecialKeys);

    glutTimerFunc(0, UpdateWheels, 0);  // Configurar el temporizador para actualizar las ruedas

    glutMainLoop();  // Iniciar el bucle principal de GLUT

    return 0;  // Salir del programa
}
